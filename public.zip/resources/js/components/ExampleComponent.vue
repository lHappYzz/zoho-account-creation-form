<script>

</script>

<template>
    <div>
        <h1>Hello from Vue.js</h1>
    </div>
</template>

<style scoped>

</style>
