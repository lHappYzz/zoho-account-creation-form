<?php

namespace App\Exceptions\ZohoCRMExceptions;

class ZohoCRMRequestFailedException extends ZohoCRMServiceException
{
    //
}
