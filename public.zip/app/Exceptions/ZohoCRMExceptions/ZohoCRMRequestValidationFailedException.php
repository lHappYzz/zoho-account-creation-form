<?php

namespace App\Exceptions\ZohoCRMExceptions;

use App\Exceptions\ZohoCRMExceptions\ZohoCRMRequestFailedException;

class ZohoCRMRequestValidationFailedException extends ZohoCRMRequestFailedException
{
    //
}
