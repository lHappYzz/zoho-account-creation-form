<?php

namespace App\Exceptions\ZohoCRMExceptions;

class ZohoCRMAccessTokenExpiredException extends ZohoCRMServiceException
{
    //
}
