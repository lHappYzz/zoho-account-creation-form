<?php

namespace App\Exceptions\ZohoCRMExceptions;

use Exception;

class ZohoCRMServiceException extends Exception
{
    //
}
